import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import * as $ from 'jquery';
import * as AdminLte from 'admin-lte';


@Component({
  selector: 'app-asidenavbar',
  templateUrl: './asidenavbar.component.html',
  styleUrls: ['./asidenavbar.component.scss']
})
export class AsidenavbarComponent implements OnInit {

  constructor(    private router: Router ) { }


Distributers(){
  this.router.navigate(['Distributers']);
}
Stock(){
  alert('s')
  this.router.navigate(['Item_Master']);
}
Customer(){
  this.router.navigate(['Customer']);
}


ngOnInit() {
    window.dispatchEvent(new Event('resize'));
    document.body.className = 'hold-transition skin-blue sidebar-mini';
}
ngAfterViewInit() {
  $('[data-widget="treeview"]').each(function() {
      AdminLte.Treeview._jQueryInterface.call($(this), 'init');
  });
}
}
