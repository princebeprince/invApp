import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
    {path: '', redirectTo: 'login', pathMatch: 'full'},
    {path: 'Distributers', redirectTo : '/Distributers'},
    {path: 'Customer', redirectTo : 'Customer' ,pathMatch: 'full'},
    {path: 'Item_Master', redirectTo : 'Item_Master' ,pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
