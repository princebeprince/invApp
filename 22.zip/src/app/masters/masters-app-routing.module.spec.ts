import { MastersAppRoutingModule } from './masters-app-routing.module';

describe('MastersAppRoutingModule', () => {
  let mastersAppRoutingModule: MastersAppRoutingModule;

  beforeEach(() => {
    mastersAppRoutingModule = new MastersAppRoutingModule();
  });

  it('should create an instance', () => {
    expect(mastersAppRoutingModule).toBeTruthy();
  });
});
