import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DistributersComponent } from './distributers/distributers.component';
import { MastersAppRoutingModule } from './/masters-app-routing.module';
import {LayoutModule} from '../layout/layout.module';
import { CustomerComponent } from './customer/customer.component';
import { ItemMasterComponent } from './item-master/item-master.component';


@NgModule({
  imports: [
    CommonModule,
    MastersAppRoutingModule,
    LayoutModule
    
  ],
  declarations: [DistributersComponent, CustomerComponent, ItemMasterComponent]
})
export class MastersModule { }
