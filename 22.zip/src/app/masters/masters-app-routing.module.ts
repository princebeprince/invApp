import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { DistributersComponent } from '../masters/distributers/distributers.component'
import { CustomerComponent } from '../masters/customer/customer.component'
import { ItemMasterComponent } from '../masters/item-master/item-master.component'

const routes: Routes = [
  {path: 'Distributers', component: DistributersComponent},
  {path: 'Customer', component: CustomerComponent},
  {path: 'Item_Master', component: ItemMasterComponent}
  ];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule] ,
  
  declarations: []
})
export class MastersAppRoutingModule { }
