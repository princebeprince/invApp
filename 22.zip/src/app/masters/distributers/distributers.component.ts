import { Component,OnDestroy, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import * as $ from 'jquery';



@Component({
  selector: 'app-distributers',
  templateUrl: './distributers.component.html',
  styleUrls: ['./distributers.component.scss']
})
export class DistributersComponent implements OnInit , OnDestroy {

  constructor(    private router: Router ) { }

  // add new distributers methode
  Distadd(){
    document.getElementById('distadder').style.display = 'Inline';
    document.getElementById('distList').style.display = 'none';
    
  }

  DistCancel(){
      this.router.navigate(['Distributers'])
  }

  ngOnInit() {

    // $(document).ready(() => {
    //   const trees: any = $('[data-widget="tree"]').Treeview('init');;
    //   trees.tree();
    // });

    // window.dispatchEvent(new Event('resize'));
    // document.body.className = 'hold-transition skin-blue sidebar-mini';
  }

  ngOnDestroy(): void {
    document.body.className = '';
}

}
